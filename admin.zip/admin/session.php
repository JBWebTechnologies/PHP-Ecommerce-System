<?php
 session_start();
 
 $_SESSION['username'] = "Aliiiiiii";
 
 echo $_SESSION['username'];
 
 
 
 
 


?>