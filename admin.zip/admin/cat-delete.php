<?php

 require_once("../dbconnect.php");
 $id = intval($_GET['id']);
 
 if($id >0){
    mysql_query("delete from tblcategory where id = $id");
    header("Location: cat-view.php?flag=1");
	exit;
	
 }



?>