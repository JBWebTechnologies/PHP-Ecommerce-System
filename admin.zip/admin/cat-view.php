<?php

 
 error_reporting(~E_NOTICE);
 
 
  $dir = "../pImages/";
 //Class object creation
 require_once("../dbconnect.php");
 $flag =  $_GET['flag'];
 $error = "";
 
 //Step 0 - include pagination class
 include_once("../classes/Pagination.php");
 
 /* Step 1 Assign Basic Variables ****/
	
	$paging = "";
	$max = 10;
	$page_limit = 15;
	$total = 0;	
	
 //Step II get total records.
 
 $cntrs    = mysql_query("SELECT count(*) from tblcategory"); 
 $totalrow = mysql_fetch_row($cntrs);	
 $total  =  $totalrow[0];

 // tell page name
 
 $_pageurl = "cat-view.php";

 //Step 3
	
	$paginate = new Paginate($page_limit, $total, $_pageurl, $max);
	$paging = $paginate->displayUl();
	$page = $paginate->currentPage;
	$paginate->start = $paginate->start -1;
	
 
 
	
 echo $sql = "select * from tblcategory order by id desc  LIMIT $paginate->start, $paginate->limit";
 $rs = mysql_query($sql); 
 
 $total = mysql_num_rows($rs); 
 $dataArray = array();
 while($row = mysql_fetch_assoc($rs)){
  
  	array_push($dataArray,$row); 	 
  
 }
 
//Step 5 copy paste
$start  = $paginate->start+1;
	$limit = $paginate->limit;
	$pageError = 0;
	
	if(($start+$total) > $total){
		$limit = $total - $start;
		$pageError = 1;
	}


 
 if($flag==1){
 	$msg = "Category deleted sucessfully!!!!";
 
 }elseif($flag ==2){
    $msg = "Category edited sucessfully!!!!";
 
 }
 
 
 
?>
<html>
<head>
<title>Administration Panel</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
			<td class="logo">
				Administration Panel</td>
		</tr>
		<tr>
			<td class="topnav" align="left">&nbsp;</td>
		</tr>
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="180px" valign="top" id="leftnav"><?php include("sidemenu.php");?></td>
			        <td valign="top" align="center">
                    
                    <table align="center" width="80%" >
                  
                    <tr><td colspan="4" align="center"><h4>View Categories</h4></td></tr>
                    <tr><td colspan="4" align="right"><a href="cat-add.php">Add new Category</a></td></tr>
                    <tr><td colspan="4" align="center"><?php if($flag){?><div align="center" style="background-color:#CCCCCC; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $msg; }?></div></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    
                  <tr>
                    <th>#</th>
                    <th>Name</th>
                    <th>Image</th>
                    <th>Actions</th>
                  </tr>
                   
               <?php 
			   $j = 1;
			   for($i = 0; $i<$total; $i++){ ?>    
                  <tr>
                    <td><?php echo $j; ?></td>
                    <td><?php echo $dataArray[$i]['cName']; ?></td>
                    <td><img src="<?php echo $dir.$dataArray[$i]['cImg']; ?>" height="100px" width="100px" /></td>
                    <td><a href="cat-edit.php?id=<?php echo $dataArray[$i]['id']; ?>">Edit</a> | <a href="cat-delete.php?id=<?php echo $dataArray[$i]['id']; ?>" onClick="return confirm('This action will delete this category? Are you sure to continue?');">Delete</a></td>
                  </tr>
                  
                  <?php $j++; } ?>
                  <tr><td colspan="4" align="center">&nbsp;</td></tr>
                    <tr><td colspan="4" align="center"><?php echo $paging; ?></td></tr>
                    
		           </table>
                    
                    
                    
                    </td>
			    </tr>
               
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
</body>
</html>