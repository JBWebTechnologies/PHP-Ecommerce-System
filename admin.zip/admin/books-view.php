include_once("../classes/Pagination.php");<?php
	/*session_start();
	if(!$_SESSION['username'] || !isset($_SESSION['id']) || empty($_SESSION['id'])){
		
			header("Location: index.php");
			exit;
		}*/

	//error_reporting(5);
	/********************
	 @title: add book
	 @author: Mazhar Iqbal
	 @date:   10 April 2010
	 @description: This scripts adds a new book to databse	
	**********************/
	
		
	include("../classes/CBooks.class.php");
	require_once("../classes/db2.class.php");
	//Include pagination class
	include_once("../classes/Pagination.php");
	
	
	
	$db = new Database();
	$db->connect();
	
	
	/* Step 1 Assign Basic Variables ****/
	
	$paging = "";
	$max = 10;
	$page_limit = 15;
	$total = 0;	
	
	//echo "SELECT count(*) as total from tbl_product";
	if($db->query("SELECT count(*) as total from tbl_product") && $db->get_num_rows() >0){
		//Fetch Result
		$rscount = $db->fetch_row();
		$total = $rscount[0];
	}
	
	$_pageurl = "books-view.php";
	
	//Step 3
	
	$paginate = new Paginate($page_limit, $total, $_pageurl, $max);
	$paging = $paginate->displayUl();
	$page = $paginate->currentPage;
	$paginate->start = $paginate->start -1;
	//Fetch All date step 4
	
	echo $query = "SELECT ID, title, price, author from tbl_product order by ID Desc 
	LIMIT $paginate->start, $paginate->limit";
	
	
	$start  = $paginate->start+1;
	$limit = $paginate->limit;
	$pageError = 0;
	
	if(($start+$total) > $total){
		$limit = $total - $start;
		$pageError = 1;
	}
	
	
?>
<html>
<head>
<title>WebShop - Administration Panel</title>
<link rel="stylesheet" type="text/css" href="../styles/admin.css"/>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
			<td class="logo">
				Administration Panel</td>
		</tr>
		<tr>
			<td class="topnav" align="left">&nbsp;</td>
		</tr>
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="180px" valign="top" id="leftnav"><?php include("sidemenu.php");?></td>
			        <td valign="top" align="center">
                    <form name="frm" method="post" enctype="multipart/form-data" >
                    <table width="100%" border="0" cellpadding="5" cellspacing="0" class="tbllisting" border="1">
                    <tr >
                    	  <td width="14%">&nbsp;</td>
                    	  <td colspan="2" align="center"><a href="books-add.php">Add New Book</a></td>
                    	  <td width="20%">&nbsp;</td>
                  	  </tr>

                    	<tr class="mainhead">
                    	  <td width="14%">&nbsp;</td>
                    	  <td colspan="2" align="center"><h1>View Books</h1></td>
                    	  <td width="20%">&nbsp;</td>
                  	  </tr>
                      
                    	<tr>
                    	  <td><strong>Title</strong></td>
                    	  <td valign="top"><strong>Price</strong></td>
                    	  <td ><strong>Author</strong></td>
                    	  <td><strong>Actions</strong></td>
                  	  </tr>
                      <?php 
					   if($db->query($query)){
					   		for($i = 0 ; $i<$db->get_num_rows(); $i++){	
								$row = $db->fetch_row();
		
							
					  ?>
                      
                      <tr>
                    	  <td><?php echo $row[1]; ?></td>
                    	  <td width="20%"><?php echo $row[2]; ?></td>
                          <td width="20%"><?php echo $row[3]; ?></td>
                          <td><a href="book-edit.php?id=<?php echo $row[0]; ?>">Edit Book</a> &nbsp;|&nbsp;<a href="book-delete.php">Delete Book</a> &nbsp;|&nbsp;<a href="books-detail.php?id=<?php echo $row[0]; ?>">Book Detail</a></td>
                  	  </tr>
                      <?php 
					  }
						}
					  
					  ?>
                      
                      <tr><td colspan="4" align="center"><br><br><?php echo $paging; ?></td></tr>

                      </table>
                      </form>
                    </td>
			    </tr>
                
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
</body>
</html>