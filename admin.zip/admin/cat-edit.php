<?php
 error_reporting(~E_NOTICE);
 
 
 require_once("../dbconnect.php");
 require_once("../classes/cCategory.class.php");
 $cat  = new cCategory();
 
 
 $id = intval($_GET['id']);
 
 $error = "";
 $dir = "../pImages/";
 
 if($_POST['sub']){
   
   $id = trim($_POST['id']);
   $cName = trim($_POST['cName']);
   $existingImg = trim($_POST['existingImg']);
   //Validation
   
   if(!$cName){
     $error  = "&nbsp;&bull;&nbsp;Category name cannot be left blank.";
   }
   
   
   if(!$error){
     //Calling setter function
	 $cat->setcName($cName);
	 
    if(is_uploaded_file($_FILES['cImg']['tmp_name'])){
	 		
			$filename = $_FILES['cImg']['name'];
			
			if(move_uploaded_file($_FILES['cImg']['tmp_name'],$dir.$filename)){
			 	$cat->setcImage($filename);
			}else{
				echo "File not uploaded";
				
			}
	 }else{
	    
	 	$cat->setcImage($existingImg);
	 
	  }
	  
	  
	  
	  //Datbase insertion code here
	  $cname = $cat->getcName();
	  $img = $cat->getcImage();
	  
	 $sql = "update tblcategory set cName =\"$cname\", cImg = \"$img\" where id = $id";
	
	  	 
	 if(mysql_query($sql)){
	 
	 	header("Location: cat-view.php?flag=2");
		exit;
		
	 
	 }else{
	 
	 echo "error  ";
	 }
	 	  
	  
     
   
   
   
   }
   
   
 
 }
 
 
 //Pick existing data
 
 $select = "select * from tblcategory where id = $id";
 $rs = mysql_query($select);
 $row = mysql_fetch_row($rs);
 $id = $row[0];
 $cName = $row[1];
 $filename = $row[2];
 
  
  
 
 
 
?>
<html>
<head>
<title>Administration Panel</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
			<td class="logo">
				Administration Panel</td>
		</tr>
		<tr>
			<td class="topnav" align="left">&nbsp;</td>
		</tr>
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="180px" valign="top" id="leftnav"><?php include("sidemenu.php");?></td>
			        <td valign="top" align="center">
                    <form name="form1" action="cat-edit.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id" value="<?php echo $id; ?>" />
                    <input type="hidden" name="existingImg" value="<?php echo $filename; ?>" />

                    <table align="center" width="80%" >
                  
                    <tr><td colspan="2" align="center"><h4>Edit Category</h4></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    <tr><td colspan="2" align="center"><?php if($error){?><div align="center" style="background-color:#CCCCCC; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $error; }?></div></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    
                    <tr>
                    <td>Category Name</td>
                    
                    <td><input type="text" name="cName" value="<?php echo $cName; ?>" /></td>
                    
                    </tr>
                    
                    <tr>
                    <td>Category Image</td>
                    
                    <td><input type="file" name="cImg" /><br>Existing Image<img src="<?php echo $dir.$filename; ?>" height="100px" width="100px" />
                    
                    </tr>
                    
                    <tr>
                    <td>&nbsp;</td>
                    
                    <td><input type="submit" name="sub" class="button" value="Edit Category" />&nbsp;<input type="button" name="sub" class="button" value="Back" onClick="window.location = 'cat-view.php'" /></td>
                    
                    </tr>
                    
                    </table>
                    
                    </form>
                    
                    </td>
			    </tr>
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
</body>
</html>