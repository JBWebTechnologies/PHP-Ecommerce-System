<?php
 session_start();
 error_reporting(~E_NOTICE);
 require_once('../dbconnect2.php');
 $error="";
 if($_POST['sub']){
 
 	//get data
 	$username = strtolower($_POST['username']);
	$password = $_POST['password'];
	
	
	$remember = $_POST['remember'];
	
	
	//validate
	if(!$username){
	
	   $error ="&nbsp;&bull;&nbsp;Username cannot be left blank.<br>";
	}
	
	if(!$password){
	   $error .="&nbsp;&bull;&nbsp;Password cannot be left blank.<br>";
	
	}
	
	if(!$error){
	 //validate from db
	 
	 echo $sql = "select * from tbladmin where username = \"$username\" and passwd = \"$password\"";
	 
	 $rs = mysql_query($sql);
	 
	 if(mysql_num_rows($rs) > 0){
	  ///Rememebr Cookie
	  if($remember ==1){
	  	setcookie("username",$username,time()+86400);
	  	setcookie("password",$password,time()+86400);
	  }else{
	  
	  	setcookie("username",$username,time()-172800);
	  	setcookie("password",$password,time()-172800);

	  
	  }
	  
	  ///
          	
	
	
	    $row = mysql_fetch_row($rs);
		$id = $row[0];
		$username = $row[1];
		$_SESSION['username'] = $username;
		$_SESSION['id'] =  $id;
		
		header("Location: main.php");
		exit;
		
	  
	 
	 }else{
	 
          $error = "&nbsp;&bull;&nbsp;Username / Passwrod invalid";	 
	 
	 }
	 
	 
	
	
	
	
	
	}
	
	
	
	
 } //end of post
 
 
 
 if($_COOKIE['username'] && $_COOKIE['password']){
 		
		$username = $_COOKIE['username'];
		$password = $_COOKIE['password'];
		
 
 }
 
 
?>
<html>
<head>
<title>Administration Panel</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
			<td class="logo">
				Administration Panel</td>
		</tr>
		<tr>
			<td class="topnav" align="left">&nbsp;</td>
		</tr>
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="180px" valign="top" id="leftnav"><?php include("sidemenu.php");?></td>
			        <td valign="top" align="center">
                    <form name="form1" action="index.php" method="post">
                    <table align="center" width="80%" >
                  
                    <tr><td colspan="2" align="center"><h4>Login</h4></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    <tr><td colspan="2" align="center"><?php if($error){?><div align="center" style="background-color:#CCCCCC; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $error; }?></div></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    
                    <tr>
                    <td>Username</td>
                    
                    <td><input type="text" name="username" value="<?php echo $username; ?>" /></td>
                    
                    </tr>
                    
                    <tr>
                    <td>Password</td>
                    
                    <td><input type="password" name="password" value="<?php echo $password; ?>" /> </td>
                    
                    </tr>
                    <tr>
                    <td></td>
                    
                    <td><input type="checkbox" name="remember" value="1" /> Remember Me</td>
                    
                    </tr>
                    
                    <tr>
                    <td><input type="submit" name="sub" value="Login" class="button"/></td>
                    
                    <td></td>
                    
                    </tr>
                    
                    </table>
                    
                    </form>
                    
                    </td>
			    </tr>
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
    <div style="background-color:#003399; width:200px; height:100px; color:#FFFFFF">Div here</div>
</body>
</html>