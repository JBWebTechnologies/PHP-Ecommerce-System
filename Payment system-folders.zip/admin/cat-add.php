<?php
 error_reporting(~E_NOTICE);
 
 //Class object creation
 require_once("../classes/cCategory.class.php");
 require_once("../dbconnect.php");
 
 $cat = new cCategory();
 
 $error = "";
 $dir = "../pImages/";
 if($_POST['sub']){
   
   $cName = trim($_POST['cName']);
   //Validation
   
   if(!$cName){
     $error  = "&nbsp;&bull;&nbsp;Category name cannot be left blank.";
   }
   
   
   if(!$error){
     //Calling setter function
	 $cat->setcName($cName);
	 
    if(is_uploaded_file($_FILES['cImg']['tmp_name'])){
	 		
			$filename = $_FILES['cImg']['name'];
			
			if(move_uploaded_file($_FILES['cImg']['tmp_name'],$dir.$filename)){
			 	$cat->setcImage($filename);
			}else{
				echo "File not uplloaded";
				
			}
	 }else{
	 	$cat->setcImage("");
	 
	  }
	  
	  
	  
	  //Datbase insertion code here
	  $cname = $cat->getcName();
	  $img = $cat->getcImage();
	  
	 echo  $sql = "insert into tblcategory (cName,cImg) values (\"$cname\",\"$img\") ";
	 
	 
	 if(mysql_query($sql)){
	 
	 	header("Location: cat-view.php");
		exit;
		
	 
	 }else{
	 
	 echo "error  ";
	 }
	 	  
	  
     
   
   
   
   }
   
   
 
 }
 
 
 
 
?>
<html>
<head>
<title>Administration Panel</title>
<link rel="stylesheet" type="text/css" href="styles/admin.css"/>
</head>
<body>
	<table cellspacing="0" cellpadding="0" class="maintbl" align="center">
		<tr>
			<td class="logo">
				Administration Panel</td>
		</tr>
		<tr>
			<td class="topnav" align="left">&nbsp;</td>
		</tr>
		<tr>
			<td class="middlearea" valign="top">
			<table cellspacing="0" cellpadding="10" width="100%" height="100%">
				<tr>
			    	<td width="180px" valign="top" id="leftnav"><?php include("sidemenu.php");?></td>
			        <td valign="top" align="center">
                    <form name="form1" action="cat-add.php" method="post" enctype="multipart/form-data">
                    <table align="center" width="80%" >
                  
                    <tr><td colspan="2" align="center"><h4>Add Category</h4></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    <tr><td colspan="2" align="center"><?php if($error){?><div align="center" style="background-color:#CCCCCC; color:maroon; font-weight:bold; width:350px; height:40px"><?php echo $error; }?></div></td></tr>
                    <tr><td colspan="2" align="center">&nbsp;</td></tr>
                    
                    <tr>
                    <td>Category Name</td>
                    
                    <td><input type="text" name="cName" value="<?php echo $cName; ?>" /></td>
                    
                    </tr>
                    
                    <tr>
                    <td>Category Image</td>
                    
                    <td><input type="file" name="cImg" /></td>
                    
                    </tr>
                    
                    <tr>
                    <td>&nbsp;</td>
                    
                    <td><input type="submit" name="sub" class="button" value="Add Category" />&nbsp;<input type="button" name="sub" class="button" value="Back" onClick="window.location = 'cat-view.php'" /></td>
                    
                    </tr>
                    
                    </table>
                    
                    </form>
                    
                    </td>
			    </tr>
			</table></td>
		</tr>
		<tr>
			<td class="footer">&nbsp;</td>
		</tr>
	</table>
</body>
</html>