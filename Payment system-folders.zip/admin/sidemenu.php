<link rel="stylesheet" type="text/css" href="../css/admin.css" />
<?php  

 if(isset($_SESSION['username'])){
 
 	
 
?>

<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="">
	<tr>
		<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="main.php">Home</a></td>
	</tr>
    <tr>
		<td width="528" height="19" valign="top" class="error" style="padding-left:10px;">
		<a href="cat-view.php">Manage Categories</a></td>
	</tr>
  
	<tr>
		 <td height="19" valign="top" style="padding-left:10px;" class="error"><a href="change-password.php">Change Password </a></td>
	</tr>
	<tr>
		 <td height="19" valign="top" style="padding-left:10px;" class="error"><a href="logout.php">Logout</a> </td>
	</tr>
	
	<tr>
		 <td height="37" colspan="3" valign="top">&nbsp;</td>
	</tr>
</table>

<?php
}

?>
