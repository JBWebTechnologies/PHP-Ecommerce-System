<?php
		
	class Cart{
		public $items;
		
		public  $lastitemid;
		//var $tempShip;

		function __construct()
		{
			$this->items=array();
			
		}	

		function add_item($prodId, $prodTitle, $prodPrice, $image, $qty)
		{ 
		
		//echo $prodId."tilte".$prodTitle."price".$prodPrice."image".$image."qty".$qty;exit;
				for($i=0;$i<count($this->items);$i++)
				{
					if($this->items[$i][0]==$prodId ){
						$this->items[$i][4]+=$qty;
						$this->items[$i][5]  = $this->items[$i][4]*$this->items[$i][2];
						return;
					}
				}
						
						
			
			$item = array();
			
			$item[0]	=	$prodId;
			$item[1] 	= 	$prodTitle;
			$item[2]	=	$prodPrice;						
			$item[3]	=	$image;
			$item[4]	=	$qty; //Count;	
			$item[5]    =   $qty*$prodPrice;
			
			$this->lastitemid = 	$prodId;		
			array_push($this->items,$item);
			
			
			return;
			
		}
		
		function getCount($prod)
		{
			for($i=0;$i<count($this->items);$i++)
			{
				if($this->items[$i][0]==$prod)
				{
					return $this->items[$i][4];					
				}
			}
			return 0;
		}
		
		
		
		function get_item_count(){
			$ret=0;
			for($i=0;$i<count($this->items);$i++)
			{
				$ret += $this->items[$i][4];
			}
			return $ret;
		}
		
		function remove_item($prodId)
		{
			for($i=0;$i<count($this->items);$i++)
				if($this->items[$i][0]==$prodId)
				{
					
					array_splice($this->items,$i,1);
					return 1;
				}					
			return 0;					
		}
		
		function set_item_count($prodId,$cnt)
		{	
		
			$cnt = intval($cnt);
			
			//var_dump($choiceIds);
			if($cnt<1)
			{
				$this->remove_item($prodId);
				return;
			}			
			for($i=0;$i<count($this->items);$i++)
				if($this->items[$i][0]==$prodId)
				{
					
					$this->items[$i][4]=$cnt;
					$this->items[$i][5]= $this->items[$i][4]*$this->items[$i][2];
					return 1;
				}											
		}
			
		function reitem_count($prodId,$cnt,$choicesids)
		{
			
			$_ichoices = array();
			$_ichoices = explode(",",$choicesids);
			$choicecount = count($_ichoices);
			//echo "size = $c <br><br>";
			//echo "choices = $choicesids <Br><br>";
					
			//var_dump($_ichoices);
			if($choicesids){
				for($i=0;$i<count($this->items);$i++)
				{
					$count = 0;
					if($this->items[$i][0][0]==$prodId)
					{
						for($j=0; $j<$choicecount; $j++){
							//echo "choice = $_ichoices[$j] initemchoice = $this->items[$i][1][$j][0] <BR><br>";
							if($this->items[$i][1][$j][0] == $_ichoices[$j])
							{
								$count++;
							}
						}
					//echo "count = $count <br>";
						if($count && ($count ==  $choicecount)){							
							$this->items[$i][0][5]=$cnt;				
							return;	
						}											
					}			
				}
			}
			else{
				//echo "produceid = $prodId and cnt = $cnt <br>";
				for($i=0;$i<count($this->items);$i++)
				{
					if($this->items[$i][0][0]==$prodId)
					{
						$this->items[$i][0][5]=$cnt;						
						return;
					}
				}
			}										
		}

		function calculate_total($prodId, $quan)
		{
			
			$gTotal = 0;	
			
			for($i=0;$i<count($prodId);$i++)
			{
				if($this->items[$i][0]==$prodId[$i]){
					
					$gTotal += $this->items[$i][2] * $this->items[$i][4];
				}
			}			
			return $gTotal;
			
		}
		
		function calculate_gTotal()
		{
			$gtotal = 0;
						//print_r($this->items);
			for($i=0; $i<count($this->items); $i++)
			{
				 $gtotal += $this->items[$i][2] * $this->items[$i][4];
			}
			
			return $gtotal;
		}
		
		function calculate_qty()
		{
			$ordqty = 0;
						//print_r($this->items);
			for($i=0; $i<count($this->items); $i++)
			{
				 $ordqty +=  $this->items[$i][4];
			}
			
			return $ordqty;
		}
	
	}
		
	session_start();
	
	if(!$_SESSION['cart'])
		$_SESSION['cart'] = new Cart;
?>