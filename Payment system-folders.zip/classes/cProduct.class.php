<?php 
/********cProduct class**************/

class cProduct{
	
	private $pid;
	private $pname;
	private $color;
	private $detail;
	private $feature;
	private $date;
	private $price;
	private $cid;

	public function __construct(){
		$this->pid="";
		$this->pname="";
		$this->price="";	
		$this->cid="";
		$this->color="";
		$this->detail="";
		$this->feature="";
		$this->date="";
	}	
	
	public function setPID($p_id)
	{
		$this->pid=$p_id;
	}
	public function getPID(){
	 return $this->pid;	
	}
	
	public function setpName($p_name)
	{
	$this->pname=$p_name;	
	}
	
	public function getpName()
	{
		return $this->pname;
	}
	
	public function setpColor($p_color)
	{
	$this->color=$p_color;	
	}
	
	public function getpColor()
	{
		return $this->color;
		
	}
	
	public function setpPrice($p_price)
	{
	$this->price=$p_price;	
	}
	
	public function getpPrice()
	{
		return $this->price;
	
	}
	
	public function setpDesc($p_detail)
	{
	$this->detail=$p_detail;	
	}
	
	public function getpDesc()
	{
		return $this->detail;
	
	}
	
	public function setCID($cat_id)
	{
	$this->cid=$cat_id;	
	}
	
	public function getcid()
	{
		return $this->cid;
	
	}
	
	public function setpFeature($feature)
	{
	$this->feature=$feature;	
	}
	
	public function getpFeature()
	{
		return $this->feature;
	
	}
	
	public function setpDate($p_date)
	{
	$this->date=$p_date;	
	}
	
	public function getpDate()
	{
		return $this->date;
	
	}

}
?>