<?php
function addNums($n1,$n2){
	return $n1+$n2;

}

function multiply($n1,$n2){

	return $n1*$n2;
}


require("nusoap/lib/nusoap.php");
$server = new soap_server();

$server->configureWSDL('mathServer','urn:math');
$server->register("addNums",
	array('n1' =>'xsd:integer','n2'=>'xsd:integer'),
	array('sum'=>'xsd:integer'),
	'urn:math',
	 'urn:math#addNums');
	 
$server->register("multiply",
	array('n1' =>'xsd:float','n2'=>'xsd:float'),
	array('product'=>'xsd:float'),
	'urn:math',
	 'urn:math#multiply');
	 
	 $HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
	 
	 $server->service($HTTP_RAW_POST_DATA);
	 


?>