<?php
	require("nusoap/lib/nusoap.php");
	
	$client = new nusoap_client("http://localhost/evs_webdev-49/soap/soap-server.php?wsdl");
	
	echo "<br>Calling a Web service Function<br>";
	echo "<br>**********************************<br><br>";
	echo  "Sum of 12 + 7 =  ".$client->call('addNums',array(12,7));
	echo "<br> Calling multiply function";
	
	echo  "<br>Product of 12 *  2 =  ".$client->call('multiply',array(12.00,2));
	

?>