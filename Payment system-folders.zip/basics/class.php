<?php
/**************
  @title   example class
  @author  evs developer
  @date      12-12-2010 
  @description This class is used fro products.

****************/

class cStaff{

	//Decaring Fields
   // public $name;
   private $name;
   private $email;
   //declaring methods
   private $lang; 
   
   public function __construct($n){
   
        echo "In Staff constructor<br>";
   		$this->name = $n;
		$this->email ="";
		$this->lang = array("PHP","Java");
   
   }
   
   public function setName($n){
   		$this->name = $n;
   
   }
   
   public function getName(){
   		return $this->name;
   
   }
   
    public function getArr(){
   		return $this->lang;
   
   }
   
	
}


class cManager extends cStaff{
	
 private $desg;
  public function __construct(){
     parent::__construct("abc");
  	$this->desg = "Software Engineer";
	echo "<br>In Manager Constructor";
  }
 
 
}


$child =  new cManager();

echo $child->getName();


$reflect = new ReflectionClass('cManager');

echo "<br>".$reflect;
 
///$emp = new cStaff("Ali");
//$emp->setName("Mark");

//echo "<br>Employee name is: ".$emp->getName();

//echo "Name of employee is".$emp->name;
//$arr = $emp->getArr();

//foreach($arr as $val){
	//echo "<br>Array first element".$val;
//}
?>