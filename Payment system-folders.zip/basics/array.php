<?php
error_reporting(5);

$car = array(0=>array("toyota","Corolla"),2=>array("Suzuki"));

print_r($car);
echo "<br>";
echo "<pre>";
var_dump($car);
echo "</pre>";

//$car = array("T"=>array("toyota","Corolla"),"s"=>array("Suzuki"));
//$car = array("T"=>array("car1"=>"toyota","car2"=>"Corolla"),"s"=>array("car3"=>"Suzuki"));
//echo $car["T"]["car2"];
/*$car = array("Honda","Saab","Volvo");
$car[10] = "Suzuki";
$car [55] = 123456;

$states = array("OH"=>"Ohio","NY"=>"New York","AL"=>"Alabama","TX"=>"Texas");

$states["AL"] = "Alaska"; 
echo $states["OH"];
echo $states["NY"];*/

/*echo "<br>Value at 2nd index ".$car[2];


echo "<br>Value at 7th index ".$car[7];

echo "<br>Value at 55th index ".$car[55];

echo "<br>Array Length".count($car);
*/


?>