<?php 

$age = 31;

if($age >=25 && $age <=30){
	echo "You can attend this course";

}elseif($age > 30 && $age <=35){

 echo "You got exenmption in course";
}}elseif($age > 30 && $age <=35){

 echo "You got exenmption in course";
}
}elseif($age > 40 && $age <=45){

 echo "You got exenmption in course";
}
}elseif($age > 50 && $age <=55){

 echo "You got exenmption in course";
}
}elseif($age > 30 && $age <=35){

 echo "You got exenmption in course";
}}elseif($age > 30 && $age <=35){

 echo "You got exenmption in course";
}
}elseif($age > 30 && $age <=35){

 echo "You got exenmption in course";
}


else{

  echo "You need to wait......";
}

?>