<?php 

$course = "engineering";


switch($course){

 case "computer":
  echo "You will be admitted in computer science";
  break;
  
  case "commerce":
    echo "In Commerce";
    break;
	
	default:
	echo "We dnt offer that course";
}


?>