<?php

function hello(){
	echo "Hello";


}

function sum($a,$b=""){
	$sum = $a + $b;
	 return $sum;

}


$x = 12;
$y = 15;
echo $result = sum($x,$y);
?>