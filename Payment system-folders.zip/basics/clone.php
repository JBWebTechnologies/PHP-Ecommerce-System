<?php

class cClone{

	public $name = "";
	public $email = "abc@yahoo.com";

public function __clone(){
	$this->email ="xyz@yahoo.com";

}

}


$c1 = new cClone();

$c1->name = "Ali";
echo "<br> object c1 name = ".$c1->name;
echo "<br> object c2 name = ".$c1->email;

$c2 = clone $c1;

//$c2 =  $c1;

$c2->name = "Ahmad";
 
echo "<br> object c2 name = ".$c2->name;
echo "<br> object c2 name = ".$c2->email;
echo "<br> object c1 name = ".$c1->name;
echo "<br> object c2 name = ".$c1->email;



?>