<?php

	class cParent{

	$age = "";
	public function doStuff(){
	
		echo "In do stuff function";
	}
	function __construct(){
	
		$this->age ="";
	}

}


class cChild extends cParent{

	$email = "";
	
	function __construct(){
	
		parent::__construct();
		$this->email = "";
	}
	
	public function anyFunction(){
		echo "Any Thing";
	
	}

}


$child = new cChild();

$child->anyFunction();


$reflect = new ReflectionClass('cChild');

echo "<br>".$reflect; 		










?>