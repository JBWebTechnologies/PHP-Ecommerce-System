<?php

function hello(){
	//print_r(func_get_args(0);
	//echo func_get_args[];
	if(func_num_args() >0){
	
		//echo "Hello ".func_get_args{0};
	
	}else{
	
		echo "Hello Guest";
	
	}


}

echo strlen("Pakintan");
echo strtoupper("pakistan");
echo "<br>";


echo rand(10,50);


echo "<br>";

echo  tan(45);

echo "<br>";


echo "sqrt".sqrt(121);
//hello("Ali","123");


///echo "<br> Function w/o arguments";

hello();



?>