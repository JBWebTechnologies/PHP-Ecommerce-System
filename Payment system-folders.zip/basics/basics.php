<?php 	
echo "PHP\"s book";


$num = 10;

$amount = 100;

echo "<br>in Double quotes $num";

echo '<br>in Single quotes $num';

echo "I have \$amount in my pocket";


echo "<br>c:\\windows\\wamp";

?>