<?php


 if(checkdate(2,30,2010)){
 	echo "Valid date";
 
 }else{
 
  echo "Incvalid";
 }


echo date("D F Y h:i:sa");
echo "<br>";


echo date("dS")." of ".date("F Y");
echo "<br>".date("U");
$time = getdate(1293292266);
print_r($time);

echo mktime();

$time = time();
echo "<br>".date("F d y h:i:sa",1293292266);


//echo "<br>".
?>