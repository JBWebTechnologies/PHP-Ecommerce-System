<?php 

   //echo "Helllo World!!!!!!!<br>";
   
   //echo date("Y-m-d");
   
   /* 
    This is our first prograsmme in PHP
   
   */
   
   //echo $lang = "<br>PHP";
   $lang2  = 100000000;
   //echo $lang2;
   
   //echo typeof($lang2);
   
   $a = 1;
   
   echo "<br>now inrementing".$a++;
   
   echo "<br>Post increment = ".$a;


echo  "<br>Pre inctrement = ".++$a; 


echo "<br>Addition".$num = 12 + 15;
echo "<br>Remiander".$num = 35%15;
  
  
  $str = "PHP";
  
  $str2 = " MYSQL";
   
   echo $str.$str2;
?>
