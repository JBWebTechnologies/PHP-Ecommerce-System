<?php

	error_reporting(~E_NOTICE);
	
	
	/*if($_POST['sub']){
	 	//echo $_POST['sub'];
 		$email = $_POST['email'];
		if(!strpos($email,"@") || !strpos($email,".") ){
		
		 echo "<h2>Invalid Email...</h2>";
		}
		
 		$city = $_POST['city'];
 		$passwd  = $_POST['pass'];
		$country = $_POST['country'];
		$edu  = $_POST['edu'];
		$detail = $_POST['detail'];
		$php = $_POST['php'];
		$java = $_POST['JAVA'];
		
		echo "Welcome to php forms ".$email." from ".$city." Your passwod ".$passwd."<br>";
		
		echo "<br>Country ".$country." education ".$edu." Detail ".$detail." p=".$php." J=".$java ;
		
		
		
		
		
 	}
 
 
 if($_GET['sub']){
	 	//echo $_GET['sub'];
 		$email = $_GET['email'];
		if(!strpos($email,"@") || !strpos($email,".") ){
		
		 echo "<h2>Invalid Email...</h2>";
		}
		
 		$city = $_GET['city'];
 		$passwd  = $_GET['pass'];
		$country = $_GET['country'];
		$edu  = $_GET['edu'];
		$detail = $_GET['detail'];
		$php = $_GET['php'];
		$java = $_GET['JAVA'];
		
		echo "Welcome to php forms ".$email." from ".$city." Your passwod ".$passwd."<br>";
		
		echo "<br>Country ".$country." education ".$edu." Detail ".$detail." p=".$php." J=".$java ;
		
		
		
		
		
 	}*/
	
	 if($_REQUEST['sub']){
	 	//echo $_REQUEST['sub'];
 		$email = $_REQUEST['email'];
		if(!strpos($email,"@") || !strpos($email,".") ){
		
		 echo "<h2>Invalid Email...</h2>";
		}
		
 		$city = $_REQUEST['city'];
 		$passwd  = $_REQUEST['pass'];
		$country = $_REQUEST['country'];
		$edu  = $_REQUEST['edu'];
		$detail = $_REQUEST['detail'];
		$php = $_REQUEST['php'];
		$java = $_REQUEST['JAVA'];
		
		echo "Welcome to php forms ".$email." from ".$city." Your passwod ".$passwd."<br>";
		
		echo "<br>Country ".$country." education ".$edu." Detail ".$detail." p=".$php." J=".$java ;
		
		
		
		
		
 	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form name="form1" method="POST">
Enter your Email: <input type="text" name="email" value="<?php echo $email; ?>" />
Enter your City: <input type="text" name="city" value="<?php echo $city; ?>" />
<br />
Enter your City: <input type="password" name="pass" value="" />
Country: <select name="country">
<option value="">Select Counrty</option>
<option value="pakistan" <?php if($country == "pakistan"){?> selected="selected" <?php } ?>>Pakistan</option>
<option value="USA" <?php if($country == "USA"){?> selected="selected" <?php } ?>>US</option>
<option value="UK" <?php if($country == "UK"){?> selected="selected" <?php } ?>>UK</option>


</select><br />
Education: <input type="radio" name="edu" value="Masters" <?php if($edu == "Masters") { ?> checked="checked" <?php } ?> /> Masters
<input type="radio" name="edu" value="Bachelor" /> Bachelors.
<br />

<textarea name="detail" cols="30" rows="10">Enter detail</textarea>

<input type="checkbox" name="php" value="PHP" /> PHP
<input type="checkbox" name="JAVA" value="java"/>JAVA
<input type="submit" name="sub" value="Subscribe!!!!" />
<br />

</form>
</body>
</html>
