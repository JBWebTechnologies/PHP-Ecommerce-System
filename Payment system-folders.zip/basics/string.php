<?php

$num = 10;

echo '<br>In single Quotes $num';


echo "<br> In Double Quotes $num";

$str = "php";


echo $str[0];
echo "<br>".$str{0};


$user = "mark123456789012345";

echo "<br>String Length ".strlen($user);


if(strlen($user)<6 || strlen($user) >16){
  echo "username length is invalid";

}else{

	 echo "username length is valid";
}

echo "<br><br><br>";


echo "Str to lower".strtolower("PHP");

echo "<br>Str to upper".strtoupper("php");
echo "<br>Str to ucfirst".ucfirst("php");
echo "<br>Str to uswords".ucwords("php is easy to learn.<br>");

$s = "Php is
easy 
to 

learn<br>";
echo nl2br($s);




echo strip_tags("hello there <b>here i m</b><br>abc","<br>,<b>");



echo $string = "Lahore, Rawalpindi, Islamabad, Karachi, Miultan";
 $arr = explode(",",$string);
 
 print_r($arr);
 
 
 
 $lang = array("PHP","Mysql","Java","C#","Python");
 
 echo "<br>".implode(", ",$lang);
 
 $email = "xyz@example.com";


if(strpos($email,"@") && strpos($email,".")){

 echo "<br>Email is valid";

}  


echo "<br>".str_replace("@","(at)",$email);


echo "<br>".substr("Ford 1944",5,4); 
 
 
 
 
 
 













?>