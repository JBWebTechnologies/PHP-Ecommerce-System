<?php
include("classes/db.class.php");
	$id = $_GET['id'];
	$db = new Database();
	$db->connect();
		
		if($db->query("select id, title from tbl_product where id = $id")){
		$row = $db->fetch_row();
		
			$str = "Id = ".$row[0]." Name =  ".$row[1];
		}
	
	echo $str;
	
	
	//$id = $_GET['id'];
	
	
	/*if($id ==4){
		echo "<b><h1>Your id is  $id</h1> ";		
	}else{
	
		echo "<b><h1>Your id is not 4 but $id</h1> ";		
	}*/


?>