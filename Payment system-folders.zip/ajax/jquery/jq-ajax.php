<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script type="text/javascript" src="js/jquery-1.4.2.js"></script>
<script type="text/javascript">
$(document).ready(function(){
	alert("Page loaded");
	$("a").click(function(event){
		
		$("div:hidden").show(6000);
		//event.preventDefault();
		
		$("#slidediv").slideDown("slow");
		
	});	
	
	$("#testdiv").click(function(){
		alert($("#testdiv").html());
		$("#testdiv").html("PHP Mydsql Class Jquery Ajax Lectures");		$("div:hidden").show(3000);
		alert($("#testdiv").html());
	}
	
	);
	
	
	
	//$(".test").css("background-color","pink");
	//$("tr:last").css("font-style","italic");
	//$("tr:even").css("background-color","grey");
	
});
</script>
<style>
  div { background:#de9a44; margin:3px; width:80px; 
        height:40px; display:none; float:left; }
  </style>
</head>

<body>
<a href="http://google.com">Visit Google</a>
<span id="testdiv">hello world from jqury</span>
<div class="test">div 1 here</div>

<div  style="display:none; background-color:#FF0000; height:200px;width:200px; " >div 2 here it was hidden</div>

<span class="test">span here</span>

<table border="1">
    <tr><td>Row with Index #1</td></tr>
    <tr><td>Row with Index #2</td></tr>
    <tr><td>Row with Index #3</td></tr>
    <tr><td>Row with Index #4</td></tr>
    <tr><td>Row with Index #5</td></tr>
    <tr><td>Row with Index #6</td></tr>
    <tr><td>Row with Index #7</td></tr>
    <tr><td>Row with Index #8</td></tr>
  </table>


<div id="slidediv"></div>


</body>
</html>
