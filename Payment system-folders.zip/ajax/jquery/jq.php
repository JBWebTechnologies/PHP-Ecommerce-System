<html> <head> 
	<script src="js/jquery-1.4.2.js"></script> 
	<script> $(document).ready(function(){
		$(".myClass").css("border","3px solid red"); }); 
	</script> 
	<style> div,span { 
	width: 150px; height: 60px; float:left; padding: 10px; margin: 10px; background-color: #EEEEEE; 
	} 
	</style> 
	</head> 
	<body> 
	<div class="notMe">div class="notMe"</div> 
	<div class="myClass">div class="myClass"</div> 
	<span class="myClass">span class="myClass"</span> 
    


	</body> 
	</html> 