<?php
	$dom = new DOMDocument();
	//We can create elements
	$c     = $dom->createElement("customer");
	//To set attributes we assingend to $c
	$c->setAttribute("nic","34207-187364-89");
	
	$fname = $dom->createElement("fname","Jim");
	$lname = $dom->createElement("lname","Smith");
	
	// We need to append nodes and tell
	//$dom is root element
	$dom->appendChild($c);
	$c->appendChild($fname);
	$c->appendChild($lname);
	
	
	//Save
	$dom->save("library.xml");
	$dom->saveHTMLFile("library.xml");
	//echo $dom->saveXML();	
	
	
	
	
?>