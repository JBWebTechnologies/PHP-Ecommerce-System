<?php
$dom = new DOMDocument();
//$dom->load("library.xml");
$parent = $dom->createElement("customers");


$c = $dom->createElement("customer");
$c->setAttribute("nic","37189-23456-67");

$fname = $dom->createElement("fname","Muhammad");
$lname = $dom->createElement("lname","Shahzad");

$dom->appendChild($parent);
$parent->appendChild($c);
$c->appendChild($fname);
$c->appendChild($lname);


$c = $dom->createElement("customer");
$c->setAttribute("nic","12345667");

$fname = $dom->createElement("fname","Muhammad");
$lname = $dom->createElement("lname","Ali");

$dom->appendChild($parent);
$parent->appendChild($c);
$c->appendChild($fname);
$c->appendChild($lname);
$dom->save("persons.xml");



?>