<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="text/javascript" src="js/jquery-1.4.2.js"></script>
<script language="javascript" type="text/javascript">
$(document).ready(function(){
	 alert("Thanks for visiting!");
	 $("a").click(function(event){
	 	event.preventDefault();
		alert("Will Not Take u to Jqry websites");
 	});
	
	$("#myDiv").click(function(){
	 	alert( $('#myDiv').html() );

 	});
}); 


</script>
<style >

.div1{
	background:#000; height:100px; width:100px; border: solid 1px #FF0000;

}
</style>
<title>Untitled Document</title>
</head>

<body>
<a href="http://jquery.com">Jquery website</a>
<br />

<div id="myDiv" class="div1">hello</div>

</body>
</html>
