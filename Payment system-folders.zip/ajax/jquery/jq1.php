<html>
<head>
  
  <script src="js/jquery-1.4.2.js"></script> 
  <script>
  $(document).ready(function(){
    $("tr:first").css("font-style", "italic");
  });
  </script>
  <style>
  td { color:blue; font-weight:bold; }
  </style>
</head>
<body>
  <table>
    <tr><td>Row 1</td></tr>
    <tr><td>Row 2</td></tr>
    <tr><td>Row 3</td></tr>
  </table>
</body>
</html>